var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./ExchangeRateControl/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./ExchangeRateControl/index.ts":
/*!**************************************!*\
  !*** ./ExchangeRateControl/index.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar ExchangeRateControl =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function ExchangeRateControl() {\n    this.apiUrl = \"https://api.exchangeratesapi.io/\";\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  ExchangeRateControl.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this;\n\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container = document.createElement(\"div\");\n    this._inputExchangeRate = document.createElement(\"input\");\n\n    this._inputExchangeRate.setAttribute(\"type\", \"number\");\n\n    this._inputExchangeRate.setAttribute(\"min\", \"0\");\n\n    this._inputExchangeRate.setAttribute(\"class\", \"customInputRate\");\n\n    this._inputExchangeRate.readOnly = true;\n    this._labelCurrency = document.createElement(\"label\");\n\n    this._labelCurrency.setAttribute(\"class\", \"customLabelCurrency\");\n\n    this._container.appendChild(this._labelCurrency);\n\n    this._container.appendChild(this._inputExchangeRate);\n\n    this._popContainer = document.createElement(\"div\");\n\n    this._popContainer.setAttribute(\"class\", \"customPopContainer\");\n\n    var _buttonClosePop = document.createElement(\"button\");\n\n    _buttonClosePop.setAttribute(\"class\", \"customButtonClose\");\n\n    _buttonClosePop.textContent = \"X\";\n\n    _buttonClosePop.addEventListener(\"click\", function () {\n      _this._popService.closePopup(\"exchangeRatePop\");\n    });\n\n    this._popContainer.appendChild(_buttonClosePop);\n\n    var table = document.createElement(\"table\");\n\n    this._container.appendChild(this._popContainer);\n\n    this._popContainer.appendChild(table);\n\n    table.setAttribute(\"class\", \"custom-table\");\n    var thead = document.createElement(\"thead\");\n    table.appendChild(thead); //Main Exchange Rate\n\n    this._tbodyContainer = document.createElement(\"tbody\");\n    table.appendChild(this._tbodyContainer);\n    var tr0 = document.createElement(\"tr\");\n    thead.appendChild(tr0);\n    this._thExchangeTitle = document.createElement(\"th\");\n    tr0.appendChild(this._thExchangeTitle);\n\n    this._thExchangeTitle.setAttribute(\"colspan\", \"2\");\n\n    this._thExchangeTitle.setAttribute(\"style\", \"min-width:300px\");\n\n    var tr1 = document.createElement(\"tr\");\n    thead.appendChild(tr1);\n    var thCurrency = document.createElement(\"th\");\n    tr1.appendChild(thCurrency);\n    thCurrency.innerText = \"Currency\";\n    var thRate = document.createElement(\"th\");\n    tr1.appendChild(thRate);\n    thRate.innerText = \"Rate\";\n    this._popService = this._context.factory.getPopupService();\n    var popUpOptions = {\n      closeOnOutsideClick: false,\n      content: this._popContainer,\n      name: \"exchangeRatePop\",\n      type: 1,\n      popupStyle: {\n        position: \"absolute\",\n        overflowX: \"hidden\",\n        overflowY: \"auto\",\n        flexDirection: \"column\",\n        alignItems: \"flex-end\",\n        background: \"red\",\n        maxHeight: \"100%\",\n        bottom: \"0px\",\n        top: \"0px\",\n        left: \"auto\",\n        right: \"0px\",\n        minWidth: \"340px\",\n        backgroundColor: \"rgb(255, 255, 255)\",\n        boxShadow: \"rgb(0, 0, 0) 0px 25.6px 57.6px 0px, rgb(0, 0, 0) 0px 4.8px 14.4px 0px\"\n      }\n    };\n\n    this._popService.createPopup(popUpOptions);\n\n    this._buttonOpenPop = document.createElement(\"button\");\n\n    this._buttonOpenPop.setAttribute(\"class\", \"exchangeButton\");\n\n    this._buttonOpenPop.textContent = \".\";\n\n    this._buttonOpenPop.addEventListener(\"click\", this.openPopModal.bind(this));\n\n    this._tbodyContainer.addEventListener(\"click\", this.getCurrenTrFromTable.bind(this));\n\n    this._container.appendChild(this._buttonOpenPop);\n\n    this._labelErrorNotificacion = document.createElement(\"label\");\n    this._labelErrorNotificacion.hidden = true;\n\n    this._labelErrorNotificacion.setAttribute(\"class\", \"hidden\");\n\n    this._container.appendChild(this._labelErrorNotificacion);\n\n    container.appendChild(this._container);\n\n    this._buttonOpenPop.setAttribute(\"class\", this._context.mode.isControlDisabled ? \"hidden\" : \"exchangeButton\");\n\n    this._buttonOpenPop.disabled = this._context.mode.isControlDisabled;\n    this.initializeValuesAndTag();\n  };\n  /**\r\n   * This function inicialize all tag label and input values\r\n   */\n\n\n  ExchangeRateControl.prototype.initializeValuesAndTag = function () {\n    var _this = this;\n\n    if (this._context.mode.isControlDisabled) {\n      this._labelCurrency.textContent = this._context.parameters.currencyTargetProperty.raw;\n      this._inputExchangeRate.value = this._context.parameters.rateExchangeProperty.raw.toString();\n      return;\n    }\n\n    if (!this._context.parameters.dateProperty.raw) {\n      this.setCurrenciesRateFromApi(this._context.parameters.currencyBaseProperty.raw, this._context.parameters.currencyDefaultProperty.raw, undefined, function () {\n        _this._dateValue = new Date(); //CurrencyValue is set with default currency target \n\n        _this._currencyValue = _this._context.parameters.currencyDefaultProperty.raw;\n        _this._inputExchangeRate.value = _this._allCurrencyExchangeRate.rates[_this._context.parameters.currencyDefaultProperty.raw];\n        _this._exchangeRateValue = _this._allCurrencyExchangeRate.rates[_this._context.parameters.currencyDefaultProperty.raw];\n        _this._labelCurrency.textContent = _this._currencyValue; //Set PoP's title tag\n\n        _this._thExchangeTitle.textContent = \"Base: \" + _this._context.parameters.currencyBaseProperty.raw + \" - Date: \" + _this._dateValue.toLocaleDateString();\n\n        _this._notifyOutputChanged();\n      });\n    } else {\n      this._currencyValue = this._context.parameters.currencyTargetProperty.raw ? this._context.parameters.currencyTargetProperty.raw : this._context.parameters.currencyDefaultProperty.raw;\n      this._dateValue = this._context.parameters.dateProperty.raw;\n      var dateFormat = this.getDateInFormat(this._context.parameters.dateProperty.raw);\n      this.setCurrenciesRateFromApi(this._context.parameters.currencyBaseProperty.raw, this._currencyValue, dateFormat, function () {\n        _this._exchangeRateValue = _this._context.parameters.rateExchangeProperty.raw ? _this._context.parameters.rateExchangeProperty.raw : _this._allCurrencyExchangeRate.rates[_this._currencyValue];\n        _this._inputExchangeRate.value = _this._exchangeRateValue.toString();\n        _this._labelCurrency.textContent = _this._currencyValue;\n        _this._thExchangeTitle.textContent = \"Base: \" + _this._context.parameters.currencyBaseProperty.raw + \" - Date: \" + _this._context.parameters.dateProperty.raw.toLocaleDateString();\n\n        _this._notifyOutputChanged();\n      });\n    }\n  };\n\n  ExchangeRateControl.prototype.getDateInFormat = function (date) {\n    var month = date.getMonth() + 1;\n    month = month < 10 ? \"0\" + month : month;\n    var day = date.getDate();\n    day = day < 10 ? \"0\" + day : day;\n    return date.getFullYear() + \"-\" + month + \"-\" + day;\n  };\n\n  ExchangeRateControl.prototype.openPopModal = function () {\n    this._popService.openPopup(\"exchangeRatePop\"); //this.setCurrenciesRate();\t\t\n\n  };\n  /**\r\n   *\r\n   * @param base is the currency base to exchange\r\n   * @param target is the currency object\r\n   * @param date is the date for to do query to api\r\n   * @param callback is the function executie next from set value _allCurrenciesRate\r\n   */\n\n\n  ExchangeRateControl.prototype.setCurrenciesRateFromApi = function (base, target, date, callback) {\n    var _this = this;\n\n    var dateSearch = date ? date : \"latest\";\n\n    if (this._allCurrencyExchangeRate != undefined && date == this._allCurrencyExchangeRate.date) {\n      return;\n    }\n\n    while (this._tbodyContainer.firstChild) {\n      this._tbodyContainer.removeChild(this._tbodyContainer.firstChild);\n    }\n\n    fetch(this.apiUrl + dateSearch + \"?base=\" + base).then(function (response) {\n      _this._labelErrorNotificacion.setAttribute(\"class\", \"hidden\");\n\n      response.json().then(function (result) {\n        _this._allCurrencyExchangeRate = result;\n\n        if (callback) {\n          callback();\n        }\n\n        for (var _i = 0, _a = Object.entries(result.rates); _i < _a.length; _i++) {\n          var _b = _a[_i],\n              key = _b[0],\n              value = _b[1];\n          var nwTr = document.createElement(\"tr\");\n          nwTr.setAttribute(\"data-value\", key);\n          var nw1Td = document.createElement(\"td\");\n          var nw2Td = document.createElement(\"td\");\n          nwTr.appendChild(nw1Td);\n          nwTr.appendChild(nw2Td);\n          nw1Td.textContent = key;\n          nw2Td.textContent = value.toString();\n\n          _this._tbodyContainer.appendChild(nwTr);\n        }\n      });\n    }).catch(function (error) {\n      console.log(error);\n\n      _this._labelErrorNotificacion.setAttribute(\"class\", \"customErrorLabel\");\n\n      _this._labelErrorNotificacion.textContent = \"ERROR FROM API!\";\n    });\n  };\n\n  ExchangeRateControl.prototype.getCurrenTrFromTable = function (ev) {\n    var currentHTMLElement = ev.target;\n    var parent = currentHTMLElement.parentElement;\n\n    if (parent != null && parent instanceof HTMLTableRowElement) {\n      var currencyTarget = parent.getAttribute(\"data-value\");\n\n      if (currencyTarget) {\n        this._exchangeRateValue = this._allCurrencyExchangeRate.rates[currencyTarget];\n        this._inputExchangeRate.value = this._allCurrencyExchangeRate.rates[currencyTarget];\n        this._currencyValue = currencyTarget;\n        this._labelCurrency.textContent = currencyTarget;\n\n        this._notifyOutputChanged();\n\n        this._popService.closePopup(\"exchangeRatePop\");\n      }\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  ExchangeRateControl.prototype.updateView = function (context) {\n    var _this = this;\n\n    if (this._context.parameters.dateProperty.raw.toLocaleDateString() != this._dateValue.toLocaleDateString() && !this._context.mode.isControlDisabled) {\n      this._dateValue = this._context.parameters.dateProperty.raw;\n      this._currencyValue = this._context.parameters.currencyTargetProperty.raw ? this._context.parameters.currencyTargetProperty.raw : this._context.parameters.currencyDefaultProperty.raw;\n      var dateFormat = this.getDateInFormat(this._context.parameters.dateProperty.raw);\n      this.setCurrenciesRateFromApi(this._context.parameters.currencyBaseProperty.raw, this._currencyValue, dateFormat, function () {\n        _this._exchangeRateValue = _this._context.parameters.rateExchangeProperty.raw != 0 ? _this._context.parameters.rateExchangeProperty.raw : _this._allCurrencyExchangeRate.rates[_this._currencyValue];\n        _this._inputExchangeRate.value = _this._allCurrencyExchangeRate.rates[_this._currencyValue];\n        _this._labelCurrency.textContent = _this._currencyValue;\n        _this._thExchangeTitle.textContent = \"Base: \" + _this._context.parameters.currencyBaseProperty.raw + \" - Date: \" + _this._dateValue.toLocaleDateString();\n\n        _this._notifyOutputChanged();\n      });\n    } //Hidden button if control if disabled!\n\n\n    this._buttonOpenPop.setAttribute(\"class\", this._context.mode.isControlDisabled ? \"hidden\" : \"exchangeButton\");\n\n    this._buttonOpenPop.disabled = this._context.mode.isControlDisabled;\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  ExchangeRateControl.prototype.getOutputs = function () {\n    return {\n      rateExchangeProperty: this._exchangeRateValue,\n      currencyTargetProperty: this._currencyValue,\n      dateProperty: this._dateValue\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  ExchangeRateControl.prototype.destroy = function () {\n    this._tbodyContainer.removeEventListener(\"click\", this.getCurrenTrFromTable);\n  };\n\n  return ExchangeRateControl;\n}();\n\nexports.ExchangeRateControl = ExchangeRateControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ExchangeRateControl/index.ts?");

/***/ })

/******/ });
var JAKitControls = JAKitControls || {};
JAKitControls.ExchangeRateControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ExchangeRateControl;
pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;